import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Moviedel_admin extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldmovie;
	private JTextField textFielddate;
	static int flag_dz=0; 
 JButton btnNewButton;
	String show_time=null;
	private JTextField textField_deltime;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Moviedel_admin frame = new Moviedel_admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Moviedel_admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 502, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterTheMovie = new JLabel("Enter the movie to be deleted ");
		lblEnterTheMovie.setBounds(47, 56, 193, 14);
		contentPane.add(lblEnterTheMovie);
		
		textFieldmovie = new JTextField();
		textFieldmovie.setBounds(242, 53, 103, 20);
		contentPane.add(textFieldmovie);
		textFieldmovie.setColumns(10);
		
		JLabel lblEnterDate = new JLabel("Enter  date");
		lblEnterDate.setBounds(47, 106, 150, 14);
		contentPane.add(lblEnterDate);
		
		textFielddate = new JTextField();
		textFielddate.setBounds(243, 103, 102, 20);
		contentPane.add(textFielddate);
		textFielddate.setColumns(10);
		textFielddate.setEditable(false);
		btnNewButton=new JButton("Calendar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFielddate.setText(new actualdate(new JFrame()).setPickedDate());
			}
		});
		btnNewButton.setBounds(366, 98, 120, 31);
		contentPane.add(btnNewButton);
		
		JLabel lblEnterTimings = new JLabel("Enter timings");
		lblEnterTimings.setBounds(47, 162, 150, 14);
		contentPane.add(lblEnterTimings);
		
		JButton btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int yes_no=JOptionPane.showConfirmDialog(null, "Are you sure want to delete this movie ?");
				//int yes_no=JOptionPane.showConfirmDialog(null,"Are you sure want to logout?");
				if(yes_no==JOptionPane.YES_OPTION)
				{
					String newMoviename=textFieldmovie.getText();
					if(newMoviename.compareTo("Dear Zindagi")==0)
					{
						flag_dz=1;
						//func_update(newMoviename);
						

						
					}
					try {
							
						Class.forName("com.mysql.jdbc.Driver");
						String url="jdbc:mysql://localhost:3306/movie_theatre";
						Connection cn=DriverManager.getConnection(url,"root","root");
						Statement st=cn.createStatement();
						//String date_tim=textFielddate.getText()+" "+show_time;
						String qry="delete from nowshowing where movie_name ='"+newMoviename +"' and date ='"+textFielddate.getText() +"'and show_timings = '"+textField_deltime.getText() +"'";
						st.executeUpdate(qry);
						JOptionPane.showMessageDialog(null, "Successfully Deleted");
						//System.out.println("before while");
						//int flag=0;*/
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null,"Error in the database");
						System.out.println(""+e1.getMessage());
					}
				}
			}

			private void func_update(String newMoviename) {
				// TODO Auto-generated method stub
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					String url="jdbc:mysql://localhost:3306/movie_theatre";
					Connection cn=DriverManager.getConnection(url,"root","root");
					Statement st=cn.createStatement();
					String date_tim=textFielddate.getText()+" "+show_time;
					String qry="update del_movie set type=0 where moviename ='"+newMoviename +"'";
					st.executeUpdate(qry);	
				}
				catch(Exception e1)
				{
					System.out.println(""+e1.getMessage());
				}
				
			}
		});
		btnContinue.setBounds(167, 258, 89, 23);
		contentPane.add(btnContinue);
		
		textField_deltime = new JTextField();
		textField_deltime.setBounds(241, 159, 104, 20);
		contentPane.add(textField_deltime);
		textField_deltime.setColumns(10);
		
	}
}
