import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class DeleteMovie extends JFrame {

	private JPanel contentPane;
	private JTextField textField_movdel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteMovie frame = new DeleteMovie();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteMovie() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterTheMovie = new JLabel("Enter the movie to be deleted");
		lblEnterTheMovie.setBounds(47, 42, 198, 14);
		contentPane.add(lblEnterTheMovie);
		
		textField_movdel = new JTextField();
		textField_movdel.setBounds(293, 36, 131, 20);
		contentPane.add(textField_movdel);
		textField_movdel.setColumns(10);
		
		JButton btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String movname=textField_movdel.getText();
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					String url="jdbc:mysql://localhost:3306/movie_theatre";
					Connection cn=DriverManager.getConnection(url,"root","root");
					Statement st=cn.createStatement();
					String qry="delete from nowshowing where movie_name='"+movname +"'";
					st.execute(qry);
					JOptionPane.showMessageDialog(null, "Successfully Updated nowshowing table");
			
						
					String qryinsimage="update del_movie set type=0 where moviename='"+movname +"'";
					
					st.executeUpdate(qryinsimage);
					JOptionPane.showMessageDialog(null, "Successfully Updated delmovie table");
					
					
				}
				catch(Exception e1)
				{
					System.out.println(""+e1.getMessage());
				}
			}
		});
		btnContinue.setBounds(168, 94, 89, 23);
		contentPane.add(btnContinue);
	}

}
