import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;


public class NewMovie extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblEnterTheDate;
	private JTextField textField_date;
	private JButton btnCalendar;
	String screenid=null;
	String new_show_time=null,language=null;
	JComboBox comboBoxscreen,comboBox_language;
	private JTextField textField_time;
	private JTextField textField_path;
	private JLabel lblPath;
	private JButton btnContinue;
	String spath=null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewMovie frame = new NewMovie();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewMovie() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 653, 501);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterTheMovie = new JLabel("Enter the movie to be inserted");
		lblEnterTheMovie.setBounds(10, 64, 212, 34);
		contentPane.add(lblEnterTheMovie);
		
		textField = new JTextField();
		textField.setBounds(237, 71, 113, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblEnterTheShow = new JLabel("Enter the show timings");
		lblEnterTheShow.setBounds(10, 184, 179, 14);
		contentPane.add(lblEnterTheShow);
		
	
		
		lblEnterTheDate = new JLabel("Enter the date");
		lblEnterTheDate.setBounds(10, 130, 128, 14);
		contentPane.add(lblEnterTheDate);
		textField_date = new JTextField();
		textField_date.setBounds(237, 127, 113, 20);
		contentPane.add(textField_date);
		textField_date.setColumns(10);
		textField_date.setEditable(false);
		
		btnCalendar = new JButton("Calendar");
		btnCalendar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_date.setText(new actualdate(new JFrame()).setPickedDate());
			}
		});
		btnCalendar.setBounds(365, 126, 89, 23);
		contentPane.add(btnCalendar);

		JLabel lblNewLabel = new JLabel("Language");
		lblNewLabel.setBounds(10, 109, 146, 14);
		contentPane.add(lblNewLabel);
		
	 comboBox_language = new JComboBox();
		comboBox_language.setBounds(232, 96, 118, 20);
		contentPane.add(comboBox_language);
		comboBox_language.addItem("Select");
		comboBox_language.addItem("English");
		comboBox_language.addItem("Hindi");
		comboBox_language.addItem("Kannada");
comboBox_language.addItemListener(new ItemListener() {
			
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				language=comboBox_language.getSelectedItem().toString();
			}
		});
		JLabel lblScreen = new JLabel("Screen ");
		lblScreen.setBounds(10, 226, 46, 14);
		contentPane.add(lblScreen);
		
	 comboBoxscreen = new JComboBox();
		comboBoxscreen.setBounds(237, 226, 63, 20);
		contentPane.add(comboBoxscreen);
		comboBoxscreen.addItem("Select");
		comboBoxscreen.addItem("S1");
		comboBoxscreen.addItem("S2");
		comboBoxscreen.addItem("S3");
		comboBoxscreen.addItem("S4");
		
		textField_time = new JTextField();
		textField_time.setBounds(237, 181, 113, 20);
		contentPane.add(textField_time);
		textField_time.setColumns(10);
		
		textField_path = new JTextField();
		textField_path.setBounds(237, 278, 272, 20);
		contentPane.add(textField_path);
		textField_path.setColumns(10);
		
		lblPath = new JLabel("Path for image");
		lblPath.setBounds(10, 281, 128, 14);
		contentPane.add(lblPath);
		
		btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			String newMoviename=textField.getText();
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					String url="jdbc:mysql://localhost:3306/movie_theatre";
					Connection cn=DriverManager.getConnection(url,"root","root");
					Statement st=cn.createStatement();
					spath=textField_path.getText().toString();
					new_show_time=textField_time.getText();
					
					String qry="Insert into nowshowing values('"+newMoviename +"','"+language+"','"+textField_date.getText()+"','"+new_show_time+"','"+screenid+"',0)";
					st.executeUpdate(qry);
					JOptionPane.showMessageDialog(null, "Successfully Added");
					
					ResultSet sex = st.executeQuery("select max(sno) from del_movie ");
					sex.next();
					int sno=sex.getInt(1);
						
					String qryinsimage="Insert into del_movie values("+(++sno) +",'"+newMoviename+"',1,'"+spath+"')";
					st.executeUpdate(qryinsimage);
					JOptionPane.showMessageDialog(null, "Successfully updated del_movie table");
					
						}
				catch(Exception e1)
				{
					System.out.println(""+e1.getMessage());
				}
				
			}
		});
		btnContinue.setBounds(176, 348, 89, 23);
		contentPane.add(btnContinue);
		comboBoxscreen.addItemListener(new ItemListener() {
			
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				screenid=comboBoxscreen.getSelectedItem().toString();
			}
		});
	}

}
