import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.text.SimpleDateFormat;
import java.util.*;
//create class
class actualdate
{
	//define variables
       int month = java.util.Calendar.getInstance().get(java.util.Calendar.MONTH);
        int year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        //create object of JLabel with alignment
        JLabel l = new JLabel("", JLabel.CENTER);
        //define variable
        String day = "";
        //declaration
        JDialog d;
        JButton next,prev;
        //create object of JButton
        JButton[] button = new JButton[49];
        static int flag=0;
        int i=0;
        String scurdate=null;
        public actualdate(JFrame parent)//create constructor 
        {
        	//int i=0;
        	//create object
        	//System.out.println(""+month);
        	d = new JDialog();
                //set modal true
        		d.setTitle("Calendar");
                d.setModal(true);
                Date dNow1=new Date();
                SimpleDateFormat ftonlydate = new SimpleDateFormat ("dd");
				  scurdate= ftonlydate.format(dNow1);
				
                //define string
                String[] header = { "Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat" };
                //create JPanel object and set layout
                JPanel p1 = new JPanel(new GridLayout(7, 7));
                //set size
                p1.setPreferredSize(new Dimension(430, 120));
                //for loop condition
               
                for (int x = 0; x < button.length; x++) 
                {		
                	//define variable
                        final int selection = x;
                        //create object of JButton
                        button[x] = new JButton();
                        //set focus painted false
                       button[x].setFocusPainted(false);//what is the use of this?
                        //set background colour
                        button[x].setBackground(Color.white);
                        //if loop condition
                        if (x > 6)
                        //add action listener
                        button[x].addActionListener(new ActionListener() 
                        {
                                 public void actionPerformed(ActionEvent ae) 
                                 {
                                       day = button[selection].getActionCommand();
                                       //call dispose() method
                                       d.dispose();
                                 }
                        });
                        if (x < 7)//if loop condition 
                        {
                                button[x].setText(header[x]);
                                //set fore ground colour
                                button[x].setForeground(Color.red);
                        }
                        p1.add(button[x]);//add button
                }
                //System.out.println("cur_date"+MovieShowing.sonlydate);
                //create JPanel object with grid layout
                JPanel p2 = new JPanel(new GridLayout(1, 3));
                
                //create object of button for previous month
             
             //   p2.add(previous);//add button
               //add label
                //create object of button for next month
                next = new JButton("Next >>");
                prev = new JButton(">>Prev");
                p2.add(prev);
                p2.add(l);
                prev.setVisible(false);
                //add action command
                next.addActionListener(new ActionListener()
                {
                       
                	public void actionPerformed(ActionEvent ae) 
                        {
                             //increment month by 1
                		 flag=0;
                			month++;
                             for(int i=7;i<14;i++)
                                	button[i].setEnabled(true); 
                            	for( int i=14;i<49;i++)
                                 	button[i].setEnabled(false); 
                             displayDate();
                            next.setVisible(false);
                             //call method
                           prev.setVisible(true);
                          
                          
                           
                        }
                });
               
                //add action command
                
                prev.addActionListener(new ActionListener()
                {
                        public void actionPerformed(ActionEvent ae) 
                        {
                             //increment month by 1
                             month--;
                             for(int i=7;i<35;i++)
                              	 button[i].setEnabled(false);
                               for(int i=35;i<49;i++)
                              	 button[i].setEnabled(true);
                         
                             
                             //next.setVisible(false);
                             //call method
                             prev.setVisible(false);
                             //call method
                           next.setVisible(true); 
                            displayDate();
                            for( i=7;i<49;i++)
                            {
                            	//System.out.println("i:"+button[i].getText());
                            	if((button[i].getText()).compareTo(scurdate)!=0) 
                            	button[i].setEnabled(false);
                            	else
                            	{
                            		//System.out.println("value:"+button[i].getText());
                            		break;
                            	}
                            		
                            }
                              	
                               for(;i<49;i++)
                              	 button[i].setEnabled(true);
                          
                        }
                });
               
                p2.add(next);// add next button
               
                //set border alignment
                d.add(p1, BorderLayout.CENTER);
                d.add(p2, BorderLayout.SOUTH);
                d.pack();
                //set location
                d.setLocationRelativeTo(parent);
                //call method
                displayDate();
                for( i=7;i<49;i++)
                {
                	//System.out.println("i:"+button[i].getText());
                	if((button[i].getText()).compareTo(scurdate)!=0) 
                	button[i].setEnabled(false);
                	else
                	{
                		//System.out.println("value:"+button[i].getText());
                		break;
                	}
                		
                }
                  	
                   for(;i<49;i++)
                  	 button[i].setEnabled(true);
                //set visible true
                d.setVisible(true);
              
                
        }
 
        public void displayDate() 
        {
        	int i=0;
        	for (int x = 7; x < button.length; x++)//for loop
        	button[x].setText("");//set te xt
      	        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");	
                //create object of SimpleDateFormat 
                java.util.Calendar cal = java.util.Calendar.getInstance();			
                //create object of java.util.Calendar 
                //System.out.println("month:"+month);
        	cal.set(year, month, 1); //set year, month and date
         	//define variables
        	int dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK);
        	//System.out.println("dayOfWeek:"+dayOfWeek);
        	int daysInMonth = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH);
        	//System.out.println("daysInMonth:"+daysInMonth);
        	//condition
        	for (int x = 6 + dayOfWeek, day = 1; day <= daysInMonth; x++, day++)
        	//set text
        	button[x].setText(""+day);
        	l.setText(sdf.format(cal.getTime()));
        	//set title
        	d.setTitle("Date Picker");
        	
   
        	}
        	  
        public String setPickedDate() 
        {
        	//if condition
        	
        	if (day.equals(""))
        		return day;
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.set(year, month, Integer.parseInt(day));
            return sdf.format(cal.getTime());
        }
}
 
