import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JEditorPane;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;



public class BookingMovie extends JFrame implements ItemListener {

	//protected static BookingMovie frame=new BookingMovie();
	private JPanel contentPane;
	static String date="2016-11-10",sdatesel=null;
	static int var_check=0,seats_rem=15;
	static int tickets=0,q_samosa=0,q_pepsi=0,q_popcorn=0,tickets_booked=0,fare=0;
	JComboBox  comboBox_popcorn,comboBox,comboBox_pepsi,comboBox_samosa   ;
	JCheckBox chckbxDoYouWant;
	JLabel lblSamosa,lblPepsi,lblPopcorn,lblQuantity;
	JLabel lblSeatsRemaining;
	final int cost_tickets=250;
	final int max_capacity=30;
	static String new_timing="";
	JComboBox comboBox_1;
	static String time_am_pm=null;
	static int bookinguserid4=50;
	private JTextField textField_date;
	//date2016-11-10
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					BookingMovie frame = new BookingMovie();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookingMovie() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 309);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setTitle("Book the Seats");
		setContentPane(contentPane);
		contentPane.setLayout(null);
		//contentPane.setBackground(Color.green);
		JLabel lblUsername = new JLabel(LoginPage.username_page);
		lblUsername.setBounds(0, 0, 69, 14);
		contentPane.add(lblUsername);
		lblSeatsRemaining = new JLabel("  ");
		lblSeatsRemaining.setBounds(204, 109, 208, 14);
		contentPane.add(lblSeatsRemaining);


		JButton btnNewButton = new JButton("Logout");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int yes_no=JOptionPane.showConfirmDialog(null,"Are you sure want to logout?");
				if(yes_no==JOptionPane.YES_OPTION)
				{
					setVisible(false);
					LoginPage lp=new LoginPage();
					lp.setVisible(true);
				}
			}
		});
		btnNewButton.setBounds(345, 0, 89, 23);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel = new JLabel(MovieShowing.movie_name);
		lblNewLabel.setBounds(168, 22, 105, 14);
		contentPane.add(lblNewLabel);

		JLabel lblDate = new JLabel("Date:");
		lblDate.setBounds(0, 73, 46, 14);
		contentPane.add(lblDate);

		JLabel lblNewLabel_1 = new JLabel("No.of tickets");
		lblNewLabel_1.setBounds(0, 109, 69, 14);
		contentPane.add(lblNewLabel_1);

		comboBox = new JComboBox();
		comboBox.addItem("1");
		comboBox.addItem("2");
		comboBox.addItem("3");
		comboBox.addItem("4");
		comboBox.addItem("5");
		comboBox.addItem("6");
		comboBox.addItem("7"); 
		comboBox.addItem("8");
		comboBox.addItem("9");
		comboBox.addItem("10");
		comboBox.setBounds(79, 106, 105, 20);
		contentPane.add(comboBox);
		comboBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				tickets=Integer.parseInt(comboBox.getSelectedItem().toString());
				fare=tickets*cost_tickets;
				date=textField_date.getText();
				System.out.println(""+date);

			}
		});
		JLabel lblTiming = new JLabel("Timing");
		lblTiming.setBounds(0, 50, 46, 14);
		contentPane.add(lblTiming);

		comboBox_1 = new JComboBox();
		//comboBox_1.addItem("Select");
		/*	    
		comboBox_1.addItem("12:20 pm");
		comboBox_1.addItem("2:50 pm");
		comboBox_1.addItem("5:10 pm");
	//	comboBox_1.addItem("18:00-21:00");*/
		comboBox_1.setBounds(79, 47, 105, 20);
		comboBox_1.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(comboBox_1.getSelectedItem()==null){
					System.out.println("item is null");
				}
				else
				{
				 time_am_pm=comboBox_1.getSelectedItem().toString();
				//	String t1="10:05 am";
					//String t2="12:20 pm";
					//String t3="2:50 pm";
					//String t4="5:10 pm";
					/*if(time_am_pm.compareTo(t1)==0)
					{
						new_timing="10:05";
					}
					if(time_am_pm.compareTo(t2)==0)
					{
						new_timing="12:20";
					}
					if(time_am_pm.compareTo(t3)==0)
					{
						new_timing="14:50";
					}
					if(time_am_pm.compareTo(t4)==0)
					{
						new_timing="17:10";
					}
					 	*/
					//	new_timing=comboBox_1.getSelectedItem().toString();
					//fare=tickets*cost_tickets;
					try
					{

						Class.forName("com.mysql.jdbc.Driver");
						String url_book="jdbc:mysql://localhost:3306/movie_theatre";
						Connection cn_book=DriverManager.getConnection(url_book,"root","root");
						cn_book.setAutoCommit(false);
						Statement st_book=cn_book.createStatement();
						System.out.println(MovieShowing.timing_movie);
						//String comdt=date+" "+new_timing;
						String qrymaxval="select tickets_booked from nowshowing where movie_name='"+MovieShowing.movie_name+"' and date='"+sdatesel+"' and show_timings='"+time_am_pm+"'";
						System.out.println(qrymaxval);
						ResultSet rs=st_book.executeQuery(qrymaxval);
						while(rs.next())
						{
							tickets_booked=rs.getInt(1);
							// System.out.println(""+max_tickets);
						}
						cn_book.commit();
						cn_book.close();
					}
					catch(Exception edate)
					{
						System.out.println(""+edate.getMessage());
					}
					System.out.println("Tickets_booked:"+tickets_booked);
					seats_rem=max_capacity-tickets_booked;
					System.out.println(""+seats_rem);
					lblSeatsRemaining.setText("Seats Remaining :" + seats_rem );
					System.out.println(""+seats_rem);
				}
				}
				
		});
		contentPane.add(comboBox_1);


		JButton btnConfirmBooking = new JButton("Confirm Booking");
		btnConfirmBooking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(seats_rem<tickets)
				{
					JOptionPane.showMessageDialog(null, "Choose less number of tickets!!.Theatre is almost full!!");
				}
				else
				{
					int x=JOptionPane.showConfirmDialog(null,"Do you want to confirm booking and know your actual cost??");
					if(x==JOptionPane.YES_OPTION)
					{

						try
						{

							Class.forName("com.mysql.jdbc.Driver");
							String url_book="jdbc:mysql://localhost:3306/movie_theatre";
							Connection cn_book=DriverManager.getConnection(url_book,"root","root");
							cn_book.setAutoCommit(false);
							Statement st_book=cn_book.createStatement();
							System.out.println(MovieShowing.timing_movie);
							String seat_no=""+(tickets_booked+1)+"-"+(tickets_booked+tickets);
							System.out.println(seat_no);
							//System.out.println("MovieShowing.bookinguserid:"+MovieShowing.bookinguserid);
							System.out.println("Before Increment MovieShowing.bookinguserid:"+MovieShowing.bookinguserid);
							ResultSet sex = st_book.executeQuery("select max(booking_id) from bookinginfo ");
							sex.next();
							bookinguserid4=sex.getInt(1);
							System.out.println("MovieShowing.bookinguserid:"+MovieShowing.bookinguserid);
							String qrybook="insert into bookinginfo values ('"+(bookinguserid4+1)+"','"+LoginPage.username_page+"','"+MovieShowing.movie_name+"','"+MovieShowing.language_movie+"','"+tickets+"','"+fare+"','"+seat_no+"','"+date+"','"+new_timing+"')";
							st_book.executeUpdate(qrybook);
							//String comdt=date+" "+new_timing;
							String qrymax="update nowshowing set tickets_booked=tickets_booked+'"+tickets+"' where movie_name='"+MovieShowing.movie_name+"' and date='"+date+"' and show_timings='"+new_timing+"'";
							System.out.println(""+qrymax);
							System.out.println(qrymax);
							st_book.executeUpdate(qrymax);

							cn_book.commit();
							cn_book.close();



							lblSeatsRemaining.setText("Seats Remaining " +seats_rem );

							JOptionPane.showMessageDialog(null, "Congratulations!! Seats reserved.Pay Rs "+fare+"");//CheckOut the food services!!");
							int yes_no=JOptionPane.showConfirmDialog(null,"Do you like to see our food services and order some food for the interval time ?");
							if(yes_no==JOptionPane.YES_OPTION)
							{
								setVisible(false);
								Food_service fs=new Food_service();
								fs.setVisible(true);
							}
							else
							{
								setVisible(false);
								Summary sum=new Summary();
								sum.setVisible(true);

							}
						}
						catch(Exception booking)
						{
							JOptionPane.showMessageDialog(null, "Error in Inserting the table bookinginfo");
							System.out.println(""+booking.getMessage());
						}

					}

				}
			}
		});
		btnConfirmBooking.setBounds(150, 198, 142, 23);
		contentPane.add(btnConfirmBooking);

		JButton btnCalendar = new JButton("Calendar");
		btnCalendar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)  {
				//System.out.println("inside calendar");
				//comboBox_1.removeAllItems();
				JFrame fj=new JFrame();
				textField_date.setText(new actualdate(fj).setPickedDate());
				

				//new actualdate(fj).setPickedDate();
				sdatesel=textField_date.getText().toString();

				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					String url="jdbc:mysql://localhost:3306/movie_theatre";
					Connection cn=DriverManager.getConnection(url,"root","root");
					Statement st=cn.createStatement();
					
					
					Date dnow=new Date();
					SimpleDateFormat ftdate = new SimpleDateFormat ("yyyy-MM-dd");
					String sdatecur= ftdate.format(dnow);
					System.out.println("current date"+sdatecur);
					Date dsel=ftdate.parse(sdatesel);
					Date dcur=ftdate.parse(sdatecur);
					if(dsel.after(dcur)){
						System.out.println("in the if block");
						System.out.println("Before Remove");

						// comboBox_1.removeAll();
						comboBox_1.removeAllItems();
						System.out.println("After remove");
						//comboBox_1.addItem("Select");
						String qrytimings="select show_timings from nowshowing where movie_name='"+MovieShowing.movie_name+"' and date='"+sdatesel+"'";
						ResultSet rs=st.executeQuery(qrytimings);
						//System.out.println("before while");
						int flag=0;
						while(rs.next())
						{
							flag=1;
							comboBox_1.addItem(rs.getString(1));	
						}
							if(flag==0)
							{
								JOptionPane.showMessageDialog(null, "No timings available for the corresponding date.Select another date or another movie");
							}
						System.out.println("end of if block :");
					}

					else
					{
						Date dNow = new Date( );
						SimpleDateFormat ft = new SimpleDateFormat ("HH:mm:ss");
						String s1= ft.format(dNow);
						LocalTime time = LocalTime.parse(s1);
						long cursec = time.toSecondOfDay();
						String qrytimings="select show_timings from nowshowing where movie_name='"+MovieShowing.movie_name+"' and date='"+sdatesel+"'";
						ResultSet rs=st.executeQuery(qrytimings);
						//System.out.println("before while");
						comboBox_1.removeAllItems();
						//comboBox_1.addItem("Select");
						int flag=0;
						while(rs.next())
						{
							flag=1;
							long time1=LocalTime.parse(rs.getString(1)).toSecondOfDay();
							if(cursec<time1)
							{
							//	System.out.println("10:05 am");
								comboBox_1.addItem(rs.getString(1));
							}
						}
						if(flag==0)
						{
							JOptionPane.showMessageDialog(null, "No timings available for the corresponding date.Select another date or another movie");
						}
					/*	long time1=LocalTime.parse("10:05:00").toSecondOfDay();
						long time2=LocalTime.parse("12:20:00").toSecondOfDay();
						long time3=LocalTime.parse("14:50:00").toSecondOfDay();
						long time4=LocalTime.parse("17:10:00").toSecondOfDay();
						
						
						if(cursec<time2)
						{
							System.out.println("10:05 am");
							comboBox_1.addItem("12:20 pm");
							//comboBox_1.addItem("10:05 am");
						}
						if(cursec<time3)
						{
							System.out.println("10:05 am");
							comboBox_1.addItem("2:40 pm");
						}
						if(cursec<time4)
						{
							System.out.println("10:05 am");
							comboBox_1.addItem("5:10 pm");
						}*/



						System.out.println("Same as the current date");
					}
				}
				catch(Exception datee)
				{
					datee.printStackTrace();
				}
				//System.out.println("");


			}
		});
		btnCalendar.setBounds(194, 69, 89, 23);
		contentPane.add(btnCalendar);

		textField_date = new JTextField();
		textField_date.setBounds(79, 75, 105, 20);
		contentPane.add(textField_date);
		textField_date.setColumns(10);
		textField_date.setEditable(false);



	}

	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==comboBox_samosa)
			q_samosa=Integer.parseInt(comboBox_samosa.getSelectedItem().toString());
		if(e.getSource()==comboBox_pepsi)
			q_pepsi=Integer.parseInt(comboBox_pepsi.getSelectedItem().toString());
		if(e.getSource()==comboBox_popcorn)
			q_popcorn=Integer.parseInt(comboBox_popcorn.getSelectedItem().toString());


	}
}


