import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class Food_service extends JFrame {

	Image img;
	private JPanel contentPane;
//	static Food_service frame=new Food_service();
	static int q_samosa=0,q_pepsi=0,q_popcorn=0,total_fare=0;
	JComboBox  comboBox_date,comboBox_popcorn,comboBox,comboBox_pepsi,comboBox_samosa   ;
	static int fare_samosa=0,fare_pepsi=0,fare_popcorn=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Food_service frame = new Food_service();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Food_service() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel(){
			  public void paintComponent(Graphics g) {  
			      img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/Food_Service.png");  
			     g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this);  
		}};
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Food Serivices");
		JLabel lblNewLabel = new JLabel("Food Services that you might want");
		lblNewLabel.setBounds(100, 32, 272, 14);
		contentPane.add(lblNewLabel);
		//contentPane.setBackground(Color.green);
		JLabel lblSamosa = new JLabel("Samosa");
		lblSamosa.setBounds(54, 72, 56, 14);
		contentPane.add(lblSamosa);
		
		JLabel lblPopcorn = new JLabel("Popcorn");
		lblPopcorn.setBounds(301, 72, 71, 14);
		contentPane.add(lblPopcorn);
		
		JLabel lblPepsi = new JLabel("Pepsi");
		lblPepsi.setBounds(170, 72, 46, 14);
		contentPane.add(lblPepsi);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(0, 105, 46, 14);
		contentPane.add(lblQuantity);
		
		 comboBox_samosa = new JComboBox();
		comboBox_samosa.setBounds(64, 102, 46, 20);
		comboBox_samosa.addItem("0");
		comboBox_samosa.addItem("1");
		comboBox_samosa.addItem("2");
		comboBox_samosa.addItem("3");
		comboBox_samosa.addItem("4");
		comboBox_samosa.addItem("5");
		contentPane.add(comboBox_samosa);
		
	 comboBox_pepsi = new JComboBox();
		comboBox_pepsi.setBounds(170, 102, 46, 20);
		comboBox_pepsi.addItem("0");
		comboBox_pepsi.addItem("1");
		comboBox_pepsi.addItem("2");
		comboBox_pepsi.addItem("3");
		comboBox_pepsi.addItem("4");
		comboBox_pepsi.addItem("5");
		contentPane.add(comboBox_pepsi);
		
		 comboBox_popcorn = new JComboBox();
		comboBox_popcorn.setBounds(301, 97, 46, 20);
		//comboBox_popcorn.setBounds(294, 182, 60, 20);
		comboBox_popcorn.addItem("0");
		comboBox_popcorn.addItem("1");
		comboBox_popcorn.addItem("2");
		comboBox_popcorn.addItem("3");
		comboBox_popcorn.addItem("4");
		comboBox_popcorn.addItem("5");
		contentPane.add(comboBox_popcorn);
		comboBox_popcorn.addItemListener(new ItemListener() {
			
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				q_popcorn=Integer.parseInt(comboBox_popcorn.getSelectedItem().toString());
			}
		});
		comboBox_pepsi.addItemListener(new ItemListener() {
			
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				q_pepsi=Integer.parseInt(comboBox_pepsi.getSelectedItem().toString());
			}
		});
	comboBox_samosa.addItemListener(new ItemListener() {
	
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		q_samosa=Integer.parseInt(comboBox_samosa.getSelectedItem().toString());
		
	}
});
		
		JButton btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fare_pepsi=q_pepsi*40;
				fare_popcorn=q_popcorn*80;
				fare_samosa=q_samosa*30;
				
				total_fare=fare_pepsi+fare_popcorn+fare_samosa;
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					String url_food="jdbc:mysql://localhost:3306/movie_theatre";
					Connection cn_food=DriverManager.getConnection(url_food,"root","root");
					cn_food.setAutoCommit(false);
					Statement st_food=cn_food.createStatement();
					String qryfood="insert into food_services values ('"+LoginPage.username_page+"','"+MovieShowing.movie_name+"','"+BookingMovie.date+"','"+q_samosa+"','"+q_popcorn+"','"+q_pepsi+"')";
					 st_food.executeUpdate(qryfood);
					
					 JOptionPane.showMessageDialog(null, "Congratulations!!Your Food will be delivered to you during interval time!!.Pay Rs "+total_fare+"");
					 setVisible(false);
						//FinalBooking.frame.setVisible(true);
						st_food=cn_food.createStatement();
						
						String qryupdate="update bookinginfo set ticketcost="+(total_fare+BookingMovie.fare)+" where moviename='"+MovieShowing.movie_name+"' and date='"+BookingMovie.date+"' ";
						System.out.println(qryupdate);
						st_food.executeUpdate(qryupdate);
						cn_food.commit();
						 cn_food.close();
						 //JOptionPane.showMessageDialog(null, "Successfully updated nowshowing table");
						 Summary sum=new Summary();
						 sum.setVisible(true);
				}
				catch(Exception food)
				{
					 JOptionPane.showMessageDialog(null, "Exception Raised!!");
						
					System.out.println(food.getMessage());
				}
					}
		});
		btnContinue.setBounds(139, 163, 89, 23);
		contentPane.add(btnContinue);
	}
}
