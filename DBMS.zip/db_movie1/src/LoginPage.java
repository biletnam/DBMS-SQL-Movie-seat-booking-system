import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javafx.scene.control.PasswordField;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JToggleButton;
import javax.swing.JButton;
import java.sql.*;
import javax.swing.JTable;
import java.awt.Font;

public class LoginPage extends JFrame implements ActionListener{

	//protected static LoginPage frame=new LoginPage();
	Image img;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	JLabel lblEnterPassword,lblEnterUserName;
	JButton btnContinue;
	private JLabel lblEnterUsername;
	private JTextField textField_1;
	private JLabel lblEnterPassword_1;
	private JButton btnLogin;
	private JButton btnSignup;
	private JLabel lblNewUser;
	private String user_name=null;
	static String username_page=null;
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage frame = new LoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(100, 100, 900, 333);
		contentPane = new JPanel();/*{
			  public void paintComponent(Graphics g) {  
			      img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/Food_Service.png");  
			     g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this);  
		}};*/
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Login");
		//contentPane.setBackground(Color.blue);
		//setContentPane(new JLabel(new ImageIcon("C:\\Users\\Nikhil\\Downloads\\adhm.png")));
		//setBackground(Color.black);
		lblEnterUsername = new JLabel("Enter Username");
		lblEnterUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEnterUsername.setBounds(139, 25, 107, 30);
		contentPane.add(lblEnterUsername);
	//	setBackground(Color.ORANGE);
		
		textField_1 = new JTextField();
		textField_1.setBounds(283, 31, 107, 24);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		lblEnterPassword_1 = new JLabel("Enter Password");
		lblEnterPassword_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEnterPassword_1.setBounds(149, 47, 135, 60);
		contentPane.add(lblEnterPassword_1);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s_name=textField_1.getText();
				String s_pass=passwordField.getText();
				try
				{
					if(s_name.length()==0||s_pass.length()==0)
					{
						
						JOptionPane.showMessageDialog(null, "Please enter all the fields");
						textField_1.setText("");
						passwordField.setText("");
						
					}
					else
					{
						Class.forName("com.mysql.jdbc.Driver");
						String url="jdbc:mysql://localhost:3306/movie_theatre";
						Connection cn=DriverManager.getConnection(url,"root","root");
						Statement st=cn.createStatement();
						
						String qry="select * from customer_info where username='"+s_name+"'";
						ResultSet rs=st.executeQuery(qry);
						//System.out.println("before while");
						int flag=0,x=7;
						//check if username exists or not in the table through while loop
						while(rs.next())
						{
							
							String s=rs.getString(6);
							//compare if the password is correct or not for the corresponding user name
							if(s_pass.compareTo(s)==0)
							{
								JOptionPane.showMessageDialog(null, "Login Successful!!");
								flag=1;
								textField_1.setText ("");
								 passwordField.setText("");
								 user_name=s_name;
								  x=rs.getInt(7);
								  break;
								 
															
							}
							
							
						}
						 if((x==0)&&(flag==1))
						 {
							 	setVisible(false);
								Admin_Screen al=new Admin_Screen();
								al.setVisible(true);
						 }
						 else if((x==1)&&(flag==1))
						 {
							 setVisible(false);
							 MovieShowing.Panel1.setVisible(false);
							 MovieShowing.Panel2.setVisible(false);
							 MovieShowing.Panel3.setVisible(false);
							 MovieShowing.Panel4.setVisible(false);
							 MovieShowing.Panel5.setVisible(false);
							 MovieShowing.Panel6.setVisible(false);
							 MovieShowing.Panel7.setVisible(false);
							 MovieShowing.Panel8.setVisible(false);
							 
							 String qryinv="select * from del_movie ";
								 rs=st.executeQuery(qryinv);
								 while(rs.next())
								 {
									 int ts=rs.getInt(1);
									 int ttype=rs.getInt(3);
									 if(ts==1)
									 {
										 if(ttype==0)
											 MovieShowing.Panel1.setVisible(false);
										 else
											 MovieShowing.Panel1.setVisible(true);
										 
									 }
									 
									 else if(ts==2)
									 {
										 if(ttype==0)
											 MovieShowing.Panel2.setVisible(false);
										 else
											 MovieShowing.Panel2.setVisible(true);
										 
									 }
									 
									 else if(ts==3)
									 {
										 if(ttype==0)
											 MovieShowing.Panel3.setVisible(false);
										 else
											 MovieShowing.Panel3.setVisible(true);
										 
									 }
									 
									 if(ts==4)
									 {
										 if(ttype==0)
											 MovieShowing.Panel4.setVisible(false);
										 else
											 MovieShowing.Panel4.setVisible(true);
										 
									 }
									 
									 if(ts==5)
									 {
										 if(ttype==0)
											 MovieShowing.Panel5.setVisible(false);
										 else
										 {
											 MovieShowing.Panel5.setVisible(true);
												JLabel lblNewLabel_2 = new JLabel();
												lblNewLabel_2.setBounds(0, 11, 240, 186);
												MovieShowing.Panel5.add(lblNewLabel_2);
												//contentPane.add(Panel6);
												ImageIcon background = new ImageIcon("C:/Users/Nikhil/Downloads/DoctorStrange.jpg");
												
												lblNewLabel_2.setIcon(background);
											 
										 }
											 
										 
									 }
									 
									 if(ts==6)
									 {
										 if(ttype==0)
											 MovieShowing.Panel6.setVisible(false);
										 else
										 {
											 MovieShowing.Panel6.setVisible(true);
											 JLabel lblNewLabel_3 = new JLabel();
												lblNewLabel_3.setBounds(0, 0, 250, 224);
												MovieShowing.Panel6.add(lblNewLabel_3);
												contentPane.add(MovieShowing.Panel6);
												//contentPane.add(Panel6);
												ImageIcon background = new ImageIcon(rs.getString(4));
												
												lblNewLabel_3.setIcon(background);
 
										 }
											
										 
									 }
								 }
							 MovieShowing ms=new MovieShowing();
								ms.setVisible(true);
								username_page=s_name;
						 }

						if(flag==0)
						{
							JOptionPane.showMessageDialog(null, "Incorrect Combination Of User Name and Password");
							textField_1.setText("");
							 passwordField.setText("");
							 
						}
						cn.close();
					}
				}
					catch(Exception enew)
					{
						JOptionPane.showMessageDialog(null,"Error in Database");	
						
						System.out.println(enew.getMessage());
					}
			}
		});
		btnLogin.setBounds(71, 118, 135, 38);
		contentPane.add(btnLogin);
		
		btnSignup = new JButton("SignUp");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				SignUp su=new SignUp();
				su.setVisible(true);
			}
		});
		btnSignup.setBounds(256, 118, 134, 38);
		contentPane.add(btnSignup);
		
		lblNewUser = new JLabel("New User?");
		lblNewUser.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewUser.setBounds(256, 102, 89, 14);
		contentPane.add(lblNewUser);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(283, 62, 107, 29);
		contentPane.add(passwordField);
		
		JLabel lblWelcomeToMax = new JLabel("Welcome to Max Cinemas");
		lblWelcomeToMax.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblWelcomeToMax.setBounds(214, 0, 227, 30);
		contentPane.add(lblWelcomeToMax);
		
	
		
	
		
			}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
			

	}

	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
	
		
	}
}
