import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Summary extends JFrame {

	private JPanel contentPane;
	JTable tablesum;
	private JTable table;
	static int totalfare;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Summary frame = new Summary();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Summary() {
		setTitle("Summary");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 427);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		DefaultTableModel model=new DefaultTableModel();
		
		table = new JTable(model);
		table.setBounds(37, 102, 387, 148);
		contentPane.add(table);
		
		JLabel lblNewLabel = new JLabel(" ");
		lblNewLabel.setText("Movie Name: "+MovieShowing.movie_name+" Booking ID:"+BookingMovie.bookinguserid4+" Timing :"+BookingMovie.new_timing);
		lblNewLabel.setBounds(10, 29, 414, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblThanksForBooking = new JLabel("Thanks for booking the ticket");
		lblThanksForBooking.setBounds(151, 273, 283, 32);
		contentPane.add(lblThanksForBooking);
		
		JButton btnNewButton = new JButton("Book Another TIcket");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				MovieShowing ms=new MovieShowing();
				ms.setVisible(true);
			}
		});
		btnNewButton.setBounds(151, 326, 227, 23);
		contentPane.add(btnNewButton);
		totalfare=Food_service.total_fare+BookingMovie.fare;
		model.addColumn("Ticket&food");
		model.addColumn("Each Cost");
		model.addColumn("Quantity");
		model.addColumn("Total Cost");
		model.addRow(new Object[]{"Tickets&food","Each Cost","Quantity","Total Cost"});
		model.addRow(new Object[]{"Tickets","250",""+BookingMovie.tickets,""+BookingMovie.fare,});
		model.addRow(new Object[]{"Samosa","30",""+Food_service.q_samosa,""+Food_service.fare_samosa});
		model.addRow(new Object[]{"Popcorn","80",""+Food_service.q_popcorn,""+Food_service.fare_popcorn});
		model.addRow(new Object[]{"Pepsi","40",""+Food_service.q_pepsi,""+Food_service.fare_pepsi});
		//model.addRow(new Object[]{"Pepsi","40",""+Food_service.q_pepsi,""+Food_service.fare_pepsi});
		model.addRow(new Object[]{"","Total","",""+(Food_service.total_fare+BookingMovie.fare)});
		
	}
}
