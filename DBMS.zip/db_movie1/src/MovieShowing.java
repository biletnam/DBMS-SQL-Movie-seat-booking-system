import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;

public class MovieShowing extends JFrame {

	private JPanel contentPane;
//	static MovieShowing frame=new MovieShowing();
	static String movie_name=null;
	public static String timing_movie;//="9:00-12:00";
	static String language_movie;//;
	static int bookinguserid=100;
	static String curdate=null,curtim=null,sonlydate=null;
	//static JPanel Panel5,Panel6,Panel7,Panel8;
	 static JPanel Panel5 = new JPanel(); 
	 static JPanel Panel6 = new JPanel(); 
	 static JPanel Panel7 = new JPanel(); 
	 static JPanel Panel8 = new JPanel(); 
	static JPanel Panel1 = new JPanel(){  
		   public void paintComponent(Graphics g) {  
			     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/dz.jpg");  
			     g.drawImage(img, 0, 0, 250,207, this);  
			     }  
			   };
			 
			   static JPanel Panel2 = new JPanel(){  
		   public void paintComponent(Graphics g) {  
			     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/DoctorStrange.jpg");  
			     g.drawImage(img, 0, 0, 250,207, this);  
			     }  
			   };
			   static JPanel Panel3 = new JPanel(){  
		   public void paintComponent(Graphics g) {  
			     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/arrivalposter.jpg");  
			     g.drawImage(img, 0, 0,250,207, this);  
			     }  
			   };
			   static JPanel Panel4 = new JPanel(){  
		   public void paintComponent(Graphics g) {  
			     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/ns.jpg");  
			     g.drawImage(img, 0, 0,250,207, this);  
			     }  
			   };
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MovieShowing frame = new MovieShowing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MovieShowing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//	setBounds(100, 100, 1800, 800);
		setSize(1500, 780);
		//setResizable(false);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Movie Showing");
		
				  /* Panel5 = new JPanel(){  
					   public void paintComponent(Graphics g) {  
						     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/dz.jpg");  
						     g.drawImage(img, 0, 0, 250,207, this);  
						     }  
						   };
						   if(Moviedel_admin.flag_dz==1)
						   {
							   Panel1.setVisible(false);
						   }
				Panel6 = new JPanel(){  
					   public void paintComponent(Graphics g) {  
						     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/DoctorStrange.jpg");  
						     g.drawImage(img, 0, 0, 250,207, this);  
						     }  
						   };
				Panel7 = new JPanel(){  
					   public void paintComponent(Graphics g) {  
						     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/arrivalposter.jpg");  
						     g.drawImage(img, 0, 0,250,207, this);  
						     }  
						   };
				Panel8 = new JPanel(){  
					   public void paintComponent(Graphics g) {  
						     Image img = Toolkit.getDefaultToolkit().getImage("C:/Users/Nikhil/Downloads/ns.jpg");  
						     g.drawImage(img, 0, 0, 250,207, this);  
						     }  
						   };*/
		Panel1.setBounds(30, 150, 250,254);
		//Panel1.setBackground(Color.BLACK);
		Panel2.setBounds(357, 150, 250,254);
		//Panel2.setBackground(Color.red);
		Panel3.setBounds(700, 150, 250,254);
		//Panel3.setBackground(Color.DARK_GRAY);
		Panel4.setBounds(1000, 150, 250,254);
		Panel5.setBounds(30, 450, 250,254);
		//Panel1.setBackground(Color.BLACK);
		Panel6.setBounds(357, 450, 250,254);
		//Panel2.setBackground(Color.red);
		Panel7.setBounds(700, 450, 250,254);
		//Panel3.setBackground(Color.DARK_GRAY);
		Panel8.setBounds(1000, 450, 250,254);
		contentPane.add(Panel1);
		contentPane.add(Panel2);
		Panel2.setLayout(null);
		
		JButton btnNewButton_ds = new JButton("Book Now");
		btnNewButton_ds.setBounds(71, 231, 114, 23);
		Panel2.add(btnNewButton_ds);
		btnNewButton_ds.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
				movie_name="Doctor Strange";
				timing_movie="15:00-17:30";
				language_movie="English";
			}
		});
		contentPane.add(Panel3);
		contentPane.add(Panel4);
		contentPane.add(Panel5);
		Panel5.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Book Now");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				func_getmovie(5);
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
				
			}

			
		});
		btnNewButton_1.setBounds(68, 231, 89, 23);
		Panel5.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(0, 11, 240, 186);
		Panel5.add(lblNewLabel_2);
		contentPane.add(Panel6);
		Panel6.setLayout(null);
		
		JButton btnBookNow_1 = new JButton("Book Now");
		btnBookNow_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				func_getmovie(6);
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
			}
		});
		btnBookNow_1.setBounds(71, 231, 89, 23);
		Panel6.add(btnBookNow_1);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBounds(0, 0, 250, 224);
		Panel6.add(lblNewLabel_3);
		contentPane.add(Panel7);
		Panel7.setLayout(null);
		
		JButton btnBookNow_2 = new JButton("Book Now");
		btnBookNow_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				func_getmovie(7);
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
			}
		});
		btnBookNow_2.setBounds(79, 231, 89, 23);
		Panel7.add(btnBookNow_2);
		contentPane.add(Panel8);
		Panel8.setLayout(null);
		
		JButton btnBookNow_3 = new JButton("Book Now");
		btnBookNow_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				func_getmovie(8);
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
			}
		});
		btnBookNow_3.setBounds(76, 231, 89, 23);
		Panel8.add(btnBookNow_3);
		func_panel();
		JLabel lblNewLabel = new JLabel("Welcome to Max Cinemas");
		lblNewLabel.setBounds(139, 23, 187, 22);
		contentPane.add(lblNewLabel);
		//contentPane.setBackground(Color.green);
		JLabel lblNewLabel_1 = new JLabel(LoginPage.username_page);
		lblNewLabel_1.setBounds(10, 0, 62, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int yes_no=JOptionPane.showConfirmDialog(null,"Are you sure want to logout?");
				if(yes_no==JOptionPane.YES_OPTION)
				{
					setVisible(false);
					LoginPage lp_frame=new LoginPage();
					lp_frame.setVisible(true);
				}
			}
		});
		btnLogout.setBounds(523, 0, 89, 23);
		contentPane.add(btnLogout);
		
		JLabel lblgetbookiding = new JLabel("Now Showing");
		lblgetbookiding.setBounds(357, 110, 172, 14);
		contentPane.add(lblgetbookiding);
		Panel4.setLayout(null);
		
		JLabel lblAeDilHai = new JLabel("Force 2");
		lblAeDilHai.setBounds(82, 5, 36, 14);
		Panel4.add(lblAeDilHai);
		Panel1.setLayout(null);
		
		JLabel lblDearZindagi = new JLabel("Dear Zindagi");
		lblDearZindagi.setBounds(95, 5, 60, 14);
		Panel1.add(lblDearZindagi);
		//conten.add(btnBookNow_adhm);
		
		JButton btnBookNow_DearZindagi = new JButton("Book Now");
		btnBookNow_DearZindagi.setBounds(59, 231, 124, 23);
		Panel1.add(btnBookNow_DearZindagi);
		btnBookNow_DearZindagi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date dNow = new Date( );
			  	SimpleDateFormat ft = new SimpleDateFormat ("HH:mm:ss");
			  	String s1= ft.format(dNow);
			  	LocalTime time = LocalTime.parse(s1);
				int secondOfDay1 = time.toSecondOfDay();
				//got current time  in seconds in secondofday1
				SimpleDateFormat ftdate = new SimpleDateFormat ("yyyy-MM-dd");
				  String sdate= ftdate.format(dNow);
				  curdate=sdate;
				  curtim=s1;
				  SimpleDateFormat ftonlydate = new SimpleDateFormat ("dd");
				  sonlydate= ftonlydate.format(dNow);
				  System.out.println("sonlydate:"+sonlydate);
				  //got current date in sdate. 
				  System.out.println(sdate);
				movie_name="Dear Zindagi";
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
				MovieShowing.timing_movie="12:00-14:30";
				language_movie="Hindi";
				System.out.println(MovieShowing.timing_movie);
			}
		});
		Panel3.setLayout(null);
		
		JLabel lblDoctorStrange = new JLabel("Doctor Strange");
		lblDoctorStrange.setBounds(88, 5, 73, 14);
		Panel3.add(lblDoctorStrange);
		
		JButton btnBookNow_msd = new JButton("Book Now");
		btnBookNow_msd.setBounds(66, 231, 114, 23);
		Panel3.add(btnBookNow_msd);
		btnBookNow_msd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
				movie_name="Rockon 2";
				timing_movie="18:00-21:00";
				language_movie="Hindi";
			}
		});
		
		JLabel rock= new JLabel("Rockon 2");
		rock.setBounds(123, 5, 44, 14);
		Panel4.add(rock);
		
		JButton btnBookNow = new JButton("Book Now");
		btnBookNow.setBounds(68, 231, 114, 23);
		Panel4.add(btnBookNow);
		btnBookNow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
				movie_name="Nataraj Service";
				timing_movie="18:00-21:00";
				language_movie="Kannada";
			}
		});
	
		JButton btnBookNow_adhm = new JButton("Book NOW");
		btnBookNow_adhm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				movie_name="Force 2";
				setVisible(false);
				BookingMovie bms=new BookingMovie();
				bms.setVisible(true);
				timing_movie="9:00-12:00";
				language_movie="Hindi";
			}
		});
		btnBookNow_adhm.setBounds(10, 100, 114, 23);
		
		JButton btnWantToReview = new JButton("Want to Review the Movie?");
		btnWantToReview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Review rv=new Review();
				rv.setVisible(true);
				}
		});
		btnWantToReview.setBounds(0, 160, 187, 23);
		contentPane.add(btnWantToReview);
		
		JButton btnNewButton = new JButton("Upcoming Movies !!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				FinalBooking fb=new FinalBooking();
				fb.setVisible(true);
			}
		});
		btnNewButton.setBounds(440, 110, 172, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNatarajService = new JLabel("Nataraj Service");
		lblNatarajService.setBounds(523, 75, 89, 14);
		contentPane.add(lblNatarajService);
	}

	protected void func_getmovie(int i) {
		// TODO Auto-generated method stub
		try
		{
		//	func_getmovie(5);
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/movie_theatre";
			Connection cn=DriverManager.getConnection(url,"root","root");
			Statement st=cn.createStatement();
			//String date_tim=textFielddate.getText()+" "+show_time;
			String qrymoviename="Select moviename from del_movie  where  sno="+i+"";
			ResultSet rs=st.executeQuery(qrymoviename);
			rs.next();
			movie_name=rs.getString(1);
		}
		catch(Exception e2)
		{
			System.out.println(""+e2.getMessage());
		}
	}

	private void func_panel() {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/movie_theatre";
			Connection cn=DriverManager.getConnection(url,"root","root");
			Statement st=cn.createStatement();
			//String date_tim=textFielddate.getText()+" "+show_time;
			String qry="Select moviename from del_movie  where  type=0";
			ResultSet rs=st.executeQuery(qry);
			while(rs.next())
			{
				String smname=rs.getString(1);
				if(smname.compareTo("Dear Zindagi")==0)
				{
					System.out.println("hello");
					//Panel1.setVisible(false);
				}
			}
		}
		catch(Exception e1)
		{
			System.out.println(""+e1.getMessage());
		}
	}
}
