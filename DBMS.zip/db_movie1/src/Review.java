import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JTable;


public class Review extends JFrame {

	//protected static Review frame=new Review();
	private JPanel contentPane;
	String rating="",movie="";
	JComboBox comboBox_movie,comboBox_rating ;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Review frame = new Review();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Review() {
		//String movie="";
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Review");
		JLabel lblUsername = new JLabel("User_name");
		lblUsername.setBounds(10, 11, 65, 14);
		contentPane.add(lblUsername);
		//contentPane.setBackground(Color.green);
		JLabel lblMovie = new JLabel("Movie");
		lblMovie.setBounds(10, 56, 46, 14);
		contentPane.add(lblMovie);
	
		comboBox_movie = new JComboBox();
		comboBox_movie.setBounds(94, 53, 98, 20);
		comboBox_movie.addItem("Aae Dil Hai Mushkil");
		comboBox_movie.addItem("Shivaay");
		comboBox_movie.addItem("MS Dhoni the untold story");
		comboBox_movie.addItem("Doctor Strange");
		comboBox_movie.addItemListener(new ItemListener() {
			
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				movie=comboBox_movie.getSelectedItem().toString();
			}
		});
		
		contentPane.add(comboBox_movie);
		
		JLabel lblRating = new JLabel("Rating");
		lblRating.setBounds(10, 100, 46, 14);
		contentPane.add(lblRating);
		
		 comboBox_rating = new JComboBox();
		comboBox_rating.setBounds(94, 97, 98, 20);
		comboBox_rating.addItem("0");
		comboBox_rating.addItem("0.5");
		comboBox_rating.addItem("1");
		comboBox_rating.addItem("1.5");
		comboBox_rating.addItem("2");
		comboBox_rating.addItem("2.5");
		comboBox_rating.addItem("3");
		comboBox_rating.addItem("3.5");
		comboBox_rating.addItem("4");
		comboBox_rating.addItem("4.5");
		comboBox_rating.addItem("5");
		//comboBox_rating.addItem("2.5");
		comboBox_rating.addItemListener(new ItemListener() {
			
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				rating=comboBox_rating.getSelectedItem().toString();
			}
		});
		contentPane.add(comboBox_rating);
		
		
		JButton btnSubmitReview = new JButton("Submit Review");
		btnSubmitReview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("com.mysql.jdbc.Driver");
					String urlreview="jdbc:mysql://localhost:3306/movie_theatre";
					Connection cnreview=DriverManager.getConnection(urlreview,"root","root");
					cnreview.setAutoCommit(false);
					Statement streview=cnreview.createStatement();
					String qryreview="insert into review values ('"+LoginPage.username_page+"','"+movie+"','"+rating+"')";
					 streview.executeUpdate(qryreview);
					cnreview.commit();
					 cnreview.close();
					
				}
				catch(Exception ereview)
				{
					JOptionPane.showMessageDialog(null, "Duplicate Entry not allowed");
					System.out.println(""+ereview.getMessage());
				}
				JOptionPane.showMessageDialog(null,"Thanks for Giving the Review");
				
				setVisible(false);
				MovieShowing msw=new MovieShowing();
				msw.setVisible(true);
				}
		});
		btnSubmitReview.setBounds(162, 155, 118, 23);
		contentPane.add(btnSubmitReview);
		
		table = new JTable();
		table.setBounds(125, 189, 46, 42);
		contentPane.add(table);
	}

}
