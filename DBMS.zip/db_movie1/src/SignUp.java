import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import com.sun.org.apache.xpath.internal.operations.And;
import com.sun.xml.internal.ws.util.StringUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class SignUp extends JFrame {

	//public static SignUp frame=new SignUp();
	private JPanel contentPane;
	private JTextField textFieldname;
	private JTextField textField_emailid;
	private JTextField textField_age;
	private JTextField textField_mobno;
	private JTextField textField_username;
	private JPasswordField passwordField;
	private JPasswordField passwordField_re;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("SignUp");
		JLabel lblEnterName = new JLabel("Name:");
		lblEnterName.setBounds(0, 42, 83, 14);
		contentPane.add(lblEnterName);
		//contentPane.setBackground(Color.green);
		textFieldname = new JTextField();
		textFieldname.setBounds(103, 39, 104, 20);
		contentPane.add(textFieldname);
		textFieldname.setColumns(10);
		
		JLabel lblEnterEmailid = new JLabel("Email id");
		lblEnterEmailid.setBounds(0, 67, 83, 27);
		contentPane.add(lblEnterEmailid);
		
		textField_emailid = new JTextField();
		textField_emailid.setBounds(103, 70, 104, 20);
		contentPane.add(textField_emailid);
		textField_emailid.setColumns(10);
		
		JLabel lblEnterAge = new JLabel("Age");
		lblEnterAge.setBounds(0, 104, 72, 14);
		contentPane.add(lblEnterAge);
		
		textField_age = new JTextField();
		textField_age.setBounds(103, 101, 104, 20);
		contentPane.add(textField_age);
		textField_age.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("MobileNumber");
		lblNewLabel.setBounds(0, 129, 96, 25);
		contentPane.add(lblNewLabel);
		
		textField_mobno = new JTextField(10);
		textField_mobno.setBounds(103, 131, 104, 20);
		contentPane.add(textField_mobno);
		textField_mobno.setColumns(10);
		
		JLabel lblEnterUserNamer = new JLabel("Enter username");
		lblEnterUserNamer.setBounds(0, 174, 104, 20);
		contentPane.add(lblEnterUserNamer);
		
		textField_username = new JTextField();
		textField_username.setBounds(103, 174, 104, 20);
		contentPane.add(textField_username);
		textField_username.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Password");
		lblNewLabel_1.setBounds(0, 227, 104, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblRetypepassword = new JLabel("Re-TypePassword");
		lblRetypepassword.setBounds(310, 227, 138, 14);
		contentPane.add(lblRetypepassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(103, 224, 104, 20);
		contentPane.add(passwordField);
		
		passwordField_re = new JPasswordField();
		passwordField_re.setBounds(421, 224, 104, 20);
		contentPane.add(passwordField_re);
		
		JButton btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s_fname=textFieldname.getText();
				String s_usname=textField_username.getText();
				String s_age=textField_age.getText();
				String s_mobil=textField_mobno.getText();
				String s_password=passwordField.getText();
				String s_cpassword=passwordField_re.getText();
				String s_emailid=textField_emailid.getText();
				try
				{
					
					//check if any field is empty or not
					boolean check=EmailCheck(s_emailid);
					
					if(s_fname.length()==0||s_usname.length()==0||s_password.length()==0||s_cpassword.length()==0||s_mobil.length()==0||s_age.length()==0||s_emailid.length()==0)
					{
						
						JOptionPane.showMessageDialog(null, "Please enter all the fields");
						textField_age.setText("");
						textField_emailid.setText("");
						textField_mobno.setText("");
						textField_username.setText("");						
						 passwordField.setText("");
						 passwordField_re.setText("");
						 
					
					}
					else if(!check)
					{
						JOptionPane.showMessageDialog(null, "Please enter a valid email address");
						
					}
					else if (s_password.compareTo(s_cpassword)!=0)
					{
						
			 			JOptionPane.showMessageDialog(null,"entered passwords do not match.Re-enter correctly");
						textField_age.setText("");
						textField_emailid.setText("");
						textField_mobno.setText("");
						textField_username.setText("");						
						 passwordField.setText("");
						 passwordField_re.setText("");
						 
					}
					else if((Pattern.matches("[a-zA-Z]+",s_mobil)&&(s_mobil.length()!=10)))
					{
						JOptionPane.showMessageDialog(null,"Please enter valid mobile number");
					}
					else if((Pattern.matches("[a-zA-Z]+",s_age)))
					{
						JOptionPane.showMessageDialog(null,"Please enter valid Age");
					}
					
					else
					{
						Class.forName("com.mysql.jdbc.Driver");
						String urlsign="jdbc:mysql://localhost:3306/movie_theatre";
						Connection cnsign=DriverManager.getConnection(urlsign,"root","root");
						cnsign.setAutoCommit(false);
						Statement stsign=cnsign.createStatement();
						
						String qry="select * from customer_info where username='"+s_usname+"'";
						ResultSet rsign=stsign.executeQuery(qry);
						//System.out.println("before while");
						int flag=0;
						//check if username exists or not in the table through while loop
						while(rsign.next())
						{
							
							flag=1;
					
						
						}
						if(flag==1)
						{
							JOptionPane.showMessageDialog(null,"username already exists!!.Try it with another user name");
							//add(log);
							textField_age.setText("");
							textField_emailid.setText("");
							textField_mobno.setText("");
							textField_username.setText("");						
							 passwordField.setText("");
							 passwordField_re.setText("");
							
								
							 
						}
						else
						{
							String qrysign="insert into customer_info values ('"+s_fname+"','"+s_emailid+"','"+s_age+"','"+s_mobil+"','"+s_usname+"','"+s_password+"',1)";
							 stsign.executeUpdate(qrysign);
							cnsign.commit();
							 cnsign.close();
							 
							 JOptionPane.showMessageDialog(null,"Congratulations!!You Have Successfully Signed Up.");
							 textField_age.setText("");
								textField_emailid.setText("");
								textField_mobno.setText("");
								textField_username.setText("");						
								 passwordField.setText("");
								 passwordField_re.setText("");
								 setVisible(false);
									MovieShowing msw=new MovieShowing();
									msw.setVisible(true);
								LoginPage.username_page=s_fname;
								
						}
						
					}
					}
					
				catch(Exception enew)
				{
					 JOptionPane.showMessageDialog(null,"Error in Database");	
					//System.out.println("Exception raised");
					System.out.println(enew.getMessage());
			
				}
			}
		});
		btnContinue.setBounds(231, 280, 89, 23);
		contentPane.add(btnContinue);
	}
	public boolean EmailCheck(String emailid) // This is pattern method import by regular class
	{
	  //  String str = "";
//	    emailid = emailID.getText().toString();

	        Pattern p =Pattern.compile("[a-zA-Z0-9_.]*@[a-zA-Z]*.[a-zA-Z]*");
	        Matcher m = p.matcher(emailid);
	        boolean bm = m.matches();
	    return bm;
	    
	}
}
