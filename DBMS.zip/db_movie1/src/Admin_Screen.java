import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Admin_Screen extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Screen frame = new Admin_Screen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_Screen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 623, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnInsertMovie = new JButton("Insert a new time slot for existing Movie");
		btnInsertMovie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Movieins_admin ma=new Movieins_admin();
				ma.setVisible(true);
			}
		});
		btnInsertMovie.setBounds(129, 60, 225, 23);
		contentPane.add(btnInsertMovie);
		
		JButton btnNewButton = new JButton("Delete a  time slot for existing Movie");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Moviedel_admin mda=new Moviedel_admin();
				mda.setVisible(true);
			}
		});
		btnNewButton.setBounds(129, 105, 225, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Delete food item");
		btnNewButton_1.setBounds(146, 220, 155, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Add food item");
		btnNewButton_2.setBounds(146, 279, 155, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Check Status of movies");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton_3.setBounds(146, 339, 155, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Insert a new Movie");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				NewMovie nm=new NewMovie();
				nm.setVisible(true);
				
			}
		});
		btnNewButton_4.setBounds(129, 149, 225, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Delete an existing movie");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				DeleteMovie nm=new DeleteMovie();
				nm.setVisible(true);
				
				
			}
		});
		btnNewButton_5.setBounds(129, 183, 225, 23);
		contentPane.add(btnNewButton_5);
	}
}
