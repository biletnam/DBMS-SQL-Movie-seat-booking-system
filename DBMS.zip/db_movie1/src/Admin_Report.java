import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;


public class Admin_Report extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	static int boxf2,boxr2,boxshiv,boxns,boxds;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Report frame = new Admin_Report();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_Report() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		func_table();
		DefaultTableModel model=new DefaultTableModel();
		
		
		table_2 = new JTable(model);
		table_2.setBounds(25, 72, 399, 149);
		contentPane.add(table_2);
		
		JLabel lblPerformanceOfThe = new JLabel("Performance of the various movies in box office");
		lblPerformanceOfThe.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPerformanceOfThe.setBounds(25, 25, 358, 14);
		contentPane.add(lblPerformanceOfThe);
		model.addColumn("Ticket&food");
		model.addColumn("Each Cost");
		model.addRow(new Object[]{"MovieName","Box Office Collection(Rs)"});
		model.addRow(new Object[]{"Doctor Strange",""+(boxds*250)});
		model.addRow(new Object[]{"Force 2",""+(boxf2*250)});
		model.addRow(new Object[]{"Nataraj Service",""+(boxns*250)});
		model.addRow(new Object[]{"RockOn 2",""+(boxr2*250)});
		model.addRow(new Object[]{"Shivaay",""+(boxshiv*250)});
		
	}

	private void func_table() {
		// TODO Auto-generated method stub
		System.out.println("Inside the function:");
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/movie_theatre";
			Connection cn=DriverManager.getConnection(url,"root","root");
			Statement st=cn.createStatement();
			
			String qry="select sum(tickets_booked) from nowshowing where movie_name='Force 2'";
			ResultSet rs=st.executeQuery(qry);
			rs.next();
			boxf2=rs.getInt(1);
			System.out.println("f2:"+boxf2);
			qry="select sum(tickets_booked) from nowshowing where movie_name='Shivaay'";
			 rs=st.executeQuery(qry);
			rs.next();
			boxshiv=rs.getInt(1);
			System.out.println("shiv:"+boxshiv);
			qry="select sum(tickets_booked) from nowshowing where movie_name='Rockon 2'";
			 rs=st.executeQuery(qry);
			rs.next();
			boxr2=rs.getInt(1);
			System.out.println("shiv:"+boxr2);
			qry="select sum(tickets_booked) from nowshowing where movie_name='Doctor Strange'";
			 rs=st.executeQuery(qry);
			rs.next();
			boxds=rs.getInt(1);
			System.out.println("shiv:"+boxds);
			qry="select sum(tickets_booked) from nowshowing where movie_name='Nataraj Service'";
			 rs=st.executeQuery(qry);
			rs.next();
			boxns=rs.getInt(1);
			System.out.println("shiv:"+boxns);
		}
		catch(Exception e)
		{
			System.out.println(""+e.getMessage());
		}
	}
}
