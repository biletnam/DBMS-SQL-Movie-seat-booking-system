import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class FinalBooking extends JFrame {

//	protected static FinalBooking frame=new FinalBooking();
	private JPanel contentPane;
	private JTable table;
	private JButton btnContinue;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FinalBooking frame = new FinalBooking();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FinalBooking() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Upcoming_Movies");
		DefaultTableModel model=new DefaultTableModel();
		JScrollPane scroll=new JScrollPane();
		contentPane.add(scroll);
		model.addColumn("movie_name");
		model.addColumn("langugae");
		model.addColumn("Date_of_release");
		table = new JTable(model);
		table.setBounds(15, 11, 409, 151);
		contentPane.add(table);
		//contentPane.setBackground(Color.green);
		btnContinue = new JButton("Continue");
		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				MovieShowing ms=new MovieShowing();
				ms.setVisible(true);
			}
		});
		btnContinue.setBounds(182, 199, 89, 23);
		contentPane.add(btnContinue);
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url_food="jdbc:mysql://localhost:3306/movie_theatre";
			Connection cn_food=DriverManager.getConnection(url_food,"root","root");
			cn_food.setAutoCommit(false);
			Statement st_food=cn_food.createStatement();
			String qry="select * from upcoming_movies";
			ResultSet rs=st_food.executeQuery(qry);
			
			//System.out.println("before while");
			int flag=0;
			//check if username exists or not in the table through while loop
			model.addRow(new Object[]{"Movie_name","Language","Release Date"});
			
			while(rs.next())
			{
				
			//	String s=rs.getString(6);
				//compare if the password is correct or not for the corresponding user name
			model.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3)});
				
			
			}
			cn_food.close();
		
		}
		catch(Exception e)
		{
			
		}
	}

}
